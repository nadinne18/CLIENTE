<?php
require_once __DIR__ . '/../vendor/autoload.php';
$mongoClient = new MongoDB\Client("mongodb+srv://nadinne:fmI8L1vaWSuLNIXl@cluster0.4ojhi.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");
$database = $mongoClient->selectDatabase('restaurante');
$tasksCollection = $database->restaurante;
$productosCollection = $database->selectCollection('productos');
?>
